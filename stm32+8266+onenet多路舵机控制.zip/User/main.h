#include "stm32f10x.h"

void delay(uint16_t time);



