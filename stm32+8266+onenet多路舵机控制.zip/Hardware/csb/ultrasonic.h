#ifndef  _ULTRASONIC_H_
#define  _ULTRASONIC_H_
#include "sys.h"
#define uint unsigned int
#define TRIG_Send  PBout(10)
#define ECHO_Reci  PBin(11)

void CH_SR04_Init(void);
float Senor_Using(void);
void NVIC_Config(void);
#endif



