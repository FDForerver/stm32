#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f10x.h"

#define SERVO_GPIO_PORT GPIOB
#define SERVO_GPIO_CLK  RCC_APB2Periph_GPIOB
#define SERVO_GPIO_PIN  GPIO_Pin_5 |GPIO_Pin_0 |GPIO_Pin_1| GPIO_Pin_4

void servo_init(void);
void Servo_Run2(uint16_t angle);
void Servo_Run(uint16_t angle);
void Servo_Run3(uint16_t angle);

void Servo_Run4(uint16_t angle);

#endif /* __SERVO_H */
