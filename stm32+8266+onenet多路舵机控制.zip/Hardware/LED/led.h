#ifndef _LED_H_
#define _LED_H_

#include "stm32f10x.h"

#define LED1_ON()  GPIO_ResetBits(GPIOC,GPIO_Pin_13)
#define LED1_OFF() 	GPIO_SetBits(GPIOC,GPIO_Pin_13)
void Led_Init(void);


#endif
